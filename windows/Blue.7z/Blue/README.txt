## v1.02 (2021-02-12) 

* Diy指针版权归作者所有，未经作者同意，禁止二次上传与贩卖~如发现欢迎举报与告知作者~ (╯°Д°)╯︵ ┻━┻，感谢各位！

（ps：指针文件可赠予他人私用，但请勿用于商业用途）

## 可以在这里找到作者：

米画师：https://www.mihuashi.com/profiles/19154
P站：     https://www.pixiv.net/users/17488193  （不怎么更新了）
D站:       https://www.deviantart.com/ghlc       （也不怎么更新了）
微博/b站ID： 广寒凉茶

