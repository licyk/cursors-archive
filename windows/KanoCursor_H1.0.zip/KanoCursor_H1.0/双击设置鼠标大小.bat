@echo off
start ms-settings:easeofaccess-mousepointer