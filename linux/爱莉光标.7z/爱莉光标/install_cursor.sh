#!/bin/bash

cursor_path=$(cd "$(dirname "$0")" ; pwd)

install_cursor() {
    mkdir -p "${HOME}/.icons" || return 1
    cp -r "${cursor_path}" "${HOME}/.icons" || return 1
    return 0
}

get_cursor_set_command() {
    local cursor_name=$1
    cat<<EOF
Cinnamon:
    gsettings set org.cinnamon.desktop.interface cursor-theme "${cursor_name}"

Gnome:
    gsettings set org.gnome.desktop.interface cursor-theme "${cursor_name}"

Mate:
    gsettings set org.mate.peripherals-mouse cursor-theme "${cursor_name}"

KDE:
    kwriteconfig5 --file kcminputrc --group Mouse --key cursorTheme "${cursor_name}"

Xfce:
    xfconf-query --channel xsettings --property /Gtk/CursorThemeName --set "${cursor_name}"
EOF
}

echo "将鼠标指针安装至 '${HOME}/.icons/爱莉光标'"

if install_cursor; then
    echo "'爱莉光标' 鼠标指针安装完成, 可使用运行下面的命令启用该鼠标指针"
    get_cursor_set_command "爱莉光标"
else
    echo "鼠标指针安装到 '${HOME}/.icons/爱莉光标' 失败, 请检查是否有 root 权限或者检查目录是否存在"
    exit 1
fi